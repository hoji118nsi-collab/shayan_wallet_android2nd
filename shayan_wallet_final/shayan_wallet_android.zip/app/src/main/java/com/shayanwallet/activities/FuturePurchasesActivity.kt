package com.shayanwallet.activities

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.shayanwallet.R

class FuturePurchasesActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_future_purchases)

        // TODO: اضافه کردن منطق نمایش خریدهای آینده
    }
}
